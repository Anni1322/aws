const sessionSecret = "mysitesessionsecret";

const emailUser = 'anilwasisth@gmail.com';
const emailPassword = 'zpsalvotrsfluumm';
module.exports = {
    sessionSecret,
    emailUser,
    emailPassword
}